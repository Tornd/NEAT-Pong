import pygame, neat, os, random
WIDTH, HEIGHT = [1600, 900]

class Paddle:
    def __init__(self, rect):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        self.VEL = 20

    def move(self, command):
        if command > 0.5:
            self.rect.y += self.VEL
        elif command < -0.5:
            self.rect.y -= self.VEL
            
        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
        
    def draw(self, win, colour):
        pygame.draw.rect(win, colour, self.rect)
    
class Ball:
    def __init__(self, rect):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        self.vel = [random.choice([20, -20]), random.choice([20, -20])]
        
    def move(self, pos):
        self.rect.x, self.rect.y = [self.rect.x + self.vel[0], self.rect.y + self.vel[1]]
        if self.rect.y < 0:
            self.rect.y = 0
            self.vel[1] *= -1
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
            self.vel[1] *= -1
        
        
    
    def collision(self, paddle):
        if not self.rect.colliderect(paddle.rect):
            
            return False
        else:
            test_rect = pygame.Rect(self.rect.x, self.rect.y-self.vel[1], self.WIDTH, self.HEIGHT)
            if test_rect.colliderect(paddle.rect):
                if self.rect.right > paddle.rect.x and self.rect.x > paddle.rect.x:
                    self.rect.left = paddle.rect.right
                else:
                    self.rect.right = paddle.rect.left
                    
                self.vel[0] *= -1
            else:
                if self.rect.top > paddle.rect.y and self.rect.bottom > paddle.rect.y:
                    self.rect.y = paddle.rect.bottom
                else:
                    self.rect.bottom = paddle.rect.top
                self.vel[1] *= -1
        
    def draw(self, win, colour):
        pygame.draw.rect(win, colour, self.rect)
        
        

def eval_genomes(genomes, config):
    global gen
    gen += 1
    nets = []
    ge = []
    paddles = []
    balls = []
    
    
    for _, g in genomes:
        net = neat.nn.FeedForwardNetwork.create(g, config)
        nets.append(net)
        
        paddles.append([Paddle(pygame.Rect(50, HEIGHT/2-50, 30, 100)), Paddle(pygame.Rect(WIDTH-50-30, HEIGHT/2-50, 30, 100))])
        balls.append(Ball(pygame.Rect(WIDTH/2-30/2, HEIGHT/2-30/2, 30, 30)))
        
        g.fitness = 0
        ge.append(g)
        
    score = 0
    
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    
    
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    win_surf = pygame.Surface(win.get_size())
#     pygame.display.init()

    clock = pygame.time.Clock()
    run = True
    while run:
#         clock.tick(30)
        win_surf.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
                
        for x, pair in enumerate(paddles):
            for paddle in pair:
                output = nets[x].activate((paddle.rect.centery, abs(paddle.rect.centery - balls[x].rect.y)))
                paddle.move(output[0])
                paddle.draw(win_surf, (255, 255, 255))
        
        for x, ball in enumerate(balls):
            ball.move(x)
            
            for paddle in paddles[x]:
                ball.collision(paddle)
            
            ball.draw(win_surf, (255, 255, 255))
            
            if ball.rect.x > WIDTH or ball.rect.right < 0:
                ge[x].fitness -= 5
                balls.pop(x)
                paddles.pop(x)
                nets.pop(x)
                ge.pop(x)
                
                
                
        for genome in ge:
            genome.fitness += 0.1
        
#         win_surf = pygame.transform.scale_by(win_surf, 2)
        win.blit(win_surf, (0, 0))
        pygame.display.update()
        
        if len(ge) == 0:
            run = False
def run(config_path):
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction, neat.DefaultSpeciesSet, neat.DefaultStagnation, config_path)
    
    p = neat.Population(config)
    
    #----STAT REPORTERS---
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    
    global gen
    gen = 0
    winner = p.run(eval_genomes, 50)
    clock = pygame.time.Clock()
    while True:
        clock.tick(30)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e:
                    run = False
    
if __name__ == "__main__":
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, "config-feedforward.txt")
    run(config_path)
