import pygame, neat, os, random, visualize, pickle, math
WIDTH, HEIGHT = [1600, 900] #Höhe und Breite von der Pygame Fenster
window_name = "Pong with NEAT - Winkel"
pygame.font.init()

STAT_FONT = pygame.font.SysFont("timesnewroman", 50) #standard Font zum Text darstellen

class Paddle: #Schläger Klasse
    def __init__(self, rect, colour):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        self.VEL = 20
        self.colour = colour

    def move(self, command): #erhält Command im main loop, entspricht output seines Netzwerkes
        if command > 0.5: #geht nach unten
            self.rect.y += self.VEL
        elif command < -0.5: #geht nach oben
            self.rect.y -= self.VEL
        
        #behaltet schläger im Fenster
        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
        
    def draw(self, win, colour): #Schläger zeichnen
        pygame.draw.rect(win, (255, 255, 255), self.rect, width = 10) #weisse Umrandung        
        small_rect = pygame.Rect(self.rect.x+2, self.rect.y+2, self.rect.width-4, self.rect.height-4)
        pygame.draw.rect(win, colour, small_rect, width = 10) #farbige Rechteck
    
class Ball: #Ball Klasse
    def __init__(self, rect):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        vel = 20
        self.vel = [random.choice([vel, -vel]), random.choice([vel, -vel])] #Startrichtung ist zufällig
        self.score = 0
        self.fade = [0, 0]
        """ Fade wird später zu einer Surface und Rechteck
                        mit Fade wird eine durchsichtige Ball gespeichert, um immer sehen zu können,
                        welche Richtung ein Ball gehen können, auch wenn das Spiel/Training pausiert ist"""
    def move(self, pos): #bewegung des Balles
        self.rect.x, self.rect.y = [self.rect.x + self.vel[0], self.rect.y + self.vel[1]]
        #ändert Richtung, wenn es wand trifft
        if self.rect.y < 0:
            self.rect.y = 0
            self.vel[1] *= -1
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
            self.vel[1] *= -1
        
        
    
    def collision(self, paddle): #gibt aus, ob ein Kollision zwischen Schläger und Ball stattfindet
        if not self.rect.colliderect(paddle.rect):
            return False #kein Kollision fand statt
        else: #wenn es kollidiert ändert es die Richtung, je nachdem ob es rechts oder links auftrifft:
            test_rect = pygame.Rect(self.rect.x, self.rect.y-self.vel[1], self.WIDTH, self.HEIGHT)
            if test_rect.colliderect(paddle.rect):
                if self.rect.right > paddle.rect.x and self.rect.x > paddle.rect.x:
                    self.rect.left = paddle.rect.right
                else:
                    self.rect.right = paddle.rect.left
                    
                self.vel[0] *= -1
            else:
                if self.rect.top > paddle.rect.y and self.rect.bottom > paddle.rect.y:
                    self.rect.y = paddle.rect.bottom
                else:
                    self.rect.bottom = paddle.rect.top
                self.vel[1] *= -1
        self.score += 1
        return True #ein Kollision hat stattgefunden
        
    def draw(self, win, colour): #Ball zeichnen        
        if self.fade != [0, 0]: #zeichnet Fade-Ball, also durchsichtiges für Richtungsanzeige
            self.fade[0].set_alpha(50)
            win.blit(self.fade[0], (self.rect.x-self.vel[0]/5, self.rect.y-self.vel[1]/5))
            
        #Fade wird wieder neu gemacht und normales Ball wird gezeichnet
        self.fade[0] = pygame.Surface((self.rect.width, self.rect.height))
        pygame.draw.rect(self.fade[0], (255, 255, 255), pygame.Rect(0, 0, self.rect.width, self.rect.height))        
        small_rect = pygame.Rect(2, 2, self.rect.width-4, self.rect.height-4)
        pygame.draw.rect(self.fade[0], colour, small_rect)
        self.fade[1] = self.rect.copy()
        win.blit(self.fade[0], self.fade[1])
        
global slow #lässt das Spiel normal laufen
global paused #für pausieren
global max_score #Score die in einer Generation maximal erreicht werden kann
paused = False
slow = True
max_score = 20


def eval_genomes(genomes, config): #evaliert die Genomes
    global gen #Generation
    gen += 1
    nets = []
    ge = []
    paddles = []
    balls = []
    
    
    for _, g in genomes: #erstellt aus den Genomes einen Netzwerk. Dieser steuert zwei Schläger und hat sein Ball
        net = neat.nn.FeedForwardNetwork.create(g, config)
        nets.append(net)
        
        colour = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        paddles.append([Paddle(pygame.Rect(50, HEIGHT/2-50, 30, 100), colour), Paddle(pygame.Rect(WIDTH-50-30, HEIGHT/2-50, 30, 100), colour)])
        balls.append(Ball(pygame.Rect(WIDTH/2-30/2, HEIGHT/2-30/2-random.randrange(int(-HEIGHT/2), int(HEIGHT/2)), 30, 30)))
        
        g.fitness = 0
        ge.append(g)
        
    score = 0
    
    win = pygame.display.set_mode((WIDTH, HEIGHT)) #Fenster wird gemacht
    pygame.display.set_caption(window_name) #Fenstername

    clock = pygame.time.Clock()
    
    win_surf = pygame.Surface(win.get_size()) #momentan keine Funktion

    clock = pygame.time.Clock()
    run = True
    
    #-------game loop-----------
    while run:
        global paused
        global slow
        global max_score
        if slow:
            clock.tick(30) #lässt das Spiel bei 30 Frames pro Sekunde laufen. Sonst geht es so schnell es kann
            
        win_surf.fill((0, 0, 0)) #Fenster leeren
        for event in pygame.event.get(): #event handling
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE: #langsam
                    slow = not slow
                if event.key == pygame.K_ESCAPE: #pausieren
                    paused = not paused
                if event.key == pygame.K_DOWN:
                    max_score -= 1
                if event.key == pygame.K_UP:
                    max_score += 1
        
        if not paused: #wenn nicht pausiert ist, lauft das Training    
            for x, pair in enumerate(paddles): #output wird von jeder Netzwerk geholt, Schläger anhand von dem bewegt und gezeichnet
                for paddle in pair:
                    #------inputs--------
                    try:
                        angle = math.degrees(math.atan((paddle.rect.centery-balls[x].rect.centery)/(paddle.rect.centerx-balls[x].rect.centerx)))
                    except:
                        angle = 90
                    output = nets[x].activate((angle, 0))
                    paddle.move(output[0]) #output[0] entspricht "command"
                    paddle.draw(win_surf, paddle.colour)
            
            for x, ball in enumerate(balls): #Bälle gemoved und Kollision geprüft
                ball.move(x)
                
                for paddle in paddles[x]:
                    back = ball.collision(paddle)
                    if back:
                        ge[x].fitness += 10 #wenn ein Schläger ein Ball trifft, kriegt dessen Netzwerk ein Reward
                
                ball.draw(win_surf, paddles[x][0].colour)
                
                #wenn Ball links oder rechts den Bildschirm verlässt, bekommt das Netzwerk eine Strafe und wird in dieser Generation nicht mehr gezeichnet
                if ball.rect.x > WIDTH or ball.rect.right < 0:
                    if ball.rect.right < 0:
                        ydistance = paddles[x][0].rect.centery
                    else:
                        ydistance = paddles[x][1].rect.centery
                    ge[x].fitness -= 5*abs(ball.rect.centery-ydistance)/100
                    balls.pop(x)
                    paddles.pop(x)
                    nets.pop(x)
                    ge.pop(x)
                    
            if len(ge) == 0: #wenn keine Netzwerke am leben sind, nächste Generation
                run = False
                break
                
            for genome in ge: #für das Überleben gibt es ein Reward
                genome.fitness += 0.1
            

            score = balls[0].score #momentaner score
            if score == max_score:
                for genome in ge:
                    genome.fitness += 20 #wenn die max_score überschritten wird, erhalten alle lebenden Netzwerke einen Reward
                run = False
                break
            
            
            #Texte werden gezeichnet:
            score_text = STAT_FONT.render("Score: " + str(score) + "/" + str(max_score), 1, (255, 255, 255))
            win_surf.blit(score_text, (WIDTH/2 - score_text.get_width()/2, 10))
            gen_text = STAT_FONT.render("Gen: " + str(gen), 1, (255, 255, 255))
            win_surf.blit(gen_text, (100, 10))
            surv_text = STAT_FONT.render("Pop: " + str(len(paddles)), 1, (255, 255, 255))
            win_surf.blit(surv_text, (WIDTH-270, 10))
            
    #         win_surf = pygame.transform.scale_by(win_surf, 2)
            win.blit(win_surf, (0, 0))
            pygame.display.update()
        
        
            
            
            
def run(config_path): #main function
    #holt configuration Details aus dem config file
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction, neat.DefaultSpeciesSet, neat.DefaultStagnation, config_path) 
    
    #kreiert Population anhand von der configuration
    p = neat.Population(config)
    
    #----STAT REPORTERS--- erlauben es, dass gewisse Informationen in der Konsole ausgegeben werden
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    
    global gen #Generation
    gen = 0
    generations = 50 #wieviele Generationen bis Evaluation abgebrochen wird
    winner = p.run(eval_genomes, generations) #beste Netzwerk entspricht winner
    run = True
    pygame.quit()
    # beste Netzwerk speichern
    with open("./winner.pkl", "wb") as f: 
        pickle.dump(winner, f)
 
    # Display the winning genome in der Konsole
    print('\nBest genome:\n{!s}'.format(winner))

    # Show output of the most fit genome against training data.
    print('\nOutput:')
    winner_net = neat.nn.FeedForwardNetwork.create(winner, config)

    #Visuelle Darstellungen.
    node_names = {-1: 'Y-Koordinate', -2: 'Y-Abstand', 0: 'Up or Down'}
    visualize.draw_net(config, winner, True, node_names=node_names) #netzwerk struktur
    visualize.draw_net(config, winner, True, node_names=node_names, prune_unused=True)
    visualize.plot_stats(stats, ylog=False, view=True) #Fitness Graph
    visualize.plot_species(stats, view=True) #Speciation Graph
    
if __name__ == "__main__":
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, "config-feedforward.txt")
    run(config_path)
