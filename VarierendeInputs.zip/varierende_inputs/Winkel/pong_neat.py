import pygame, neat, os, random, math
WIDTH, HEIGHT = [1600, 900]
pygame.font.init()

STAT_FONT = pygame.font.SysFont("timesnewroman", 50)
class Paddle:
    def __init__(self, rect, colour):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        self.VEL = 20
        self.colour = colour

    def move(self, command):
        if command > 0.5:
            self.rect.y += self.VEL
        elif command < -0.5:
            self.rect.y -= self.VEL
            
        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
        
    def draw(self, win, colour):
        pygame.draw.rect(win, colour, self.rect, width = 10)
    
class Ball:
    def __init__(self, rect):
        self.rect = rect
        self.x, self.y, self.WIDTH, self.HEIGHT = self.rect
        self.vel = [random.choice([20, -20]), random.choice([20, -20])]
        self.score = 0
        
    def move(self, pos):
        self.rect.x, self.rect.y = [self.rect.x + self.vel[0], self.rect.y + self.vel[1]]
        if self.rect.y < 0:
            self.rect.y = 0
            self.vel[1] *= -1
        elif self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
            self.vel[1] *= -1
        
        
    
    def collision(self, paddle):
        if not self.rect.colliderect(paddle.rect):
            return False
        else:
            test_rect = pygame.Rect(self.rect.x, self.rect.y-self.vel[1], self.WIDTH, self.HEIGHT)
            if test_rect.colliderect(paddle.rect):
                if self.rect.right > paddle.rect.x and self.rect.x > paddle.rect.x:
                    self.rect.left = paddle.rect.right
                else:
                    self.rect.right = paddle.rect.left
                    
                self.vel[0] *= -1
            else:
                if self.rect.top > paddle.rect.y and self.rect.bottom > paddle.rect.y:
                    self.rect.y = paddle.rect.bottom
                else:
                    self.rect.bottom = paddle.rect.top
                self.vel[1] *= -1
        self.score += 1
        return True
        
    def draw(self, win, colour):
        pygame.draw.rect(win, colour, self.rect)
        
        

def eval_genomes(genomes, config):
    global gen
    gen += 1
    nets = []
    ge = []
    paddles = []
    balls = []
    
    
    for _, g in genomes:
        net = neat.nn.FeedForwardNetwork.create(g, config)
        nets.append(net)
        
        colour = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        paddles.append([Paddle(pygame.Rect(50, HEIGHT/2-50, 30, 100), colour), Paddle(pygame.Rect(WIDTH-50-30, HEIGHT/2-50, 30, 100), colour)])
        balls.append(Ball(pygame.Rect(WIDTH/2-30/2, HEIGHT/2-30/2, 30, 30)))
        
        g.fitness = 0
        ge.append(g)
        
    score = 0
    score_plus = False
    
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    
    
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    win_surf = pygame.Surface(win.get_size())

    clock = pygame.time.Clock()
    run = True
    while run:
#         clock.tick(30)
        win_surf.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
                
        for x, pair in enumerate(paddles):
            for paddle in pair:
                if (paddle.rect.centerx-balls[x].rect.centerx) != 0:
                #--------inputs---------
                    angle = math.degrees(math.atan((paddle.rect.centery-balls[x].rect.centery)/(paddle.rect.centerx-balls[x].rect.centerx)))
                
                output = nets[x].activate((angle, 0))
                paddle.move(output[0])
                paddle.draw(win_surf, paddle.colour)
        
        for x, ball in enumerate(balls):
            ball.move(x)
            
            for paddle in paddles[x]:
                back = ball.collision(paddle)
                if back:
                    score_plus = True
            
            ball.draw(win_surf, paddles[x][0].colour)
            
            if ball.rect.x > WIDTH or ball.rect.right < 0:
                ge[x].fitness -= 5
                balls.pop(x)
                paddles.pop(x)
                nets.pop(x)
                ge.pop(x)
                
        if len(ge) == 0:
            run = False
            break
            
        for genome in ge:
            genome.fitness += 0.1
        

        score = balls[0].score
        if score == 50:
            run = False
            break
        score_text = STAT_FONT.render("Score: " + str(score), 1, (255, 255, 255))
        win_surf.blit(score_text, (WIDTH/2 - score_text.get_width()/2, 10))
        gen_text = STAT_FONT.render("Gen: " + str(gen), 1, (255, 255, 255))
        win_surf.blit(gen_text, (100, 10))
        
#         win_surf = pygame.transform.scale_by(win_surf, 2)
        win.blit(win_surf, (0, 0))
        pygame.display.update()
        
        
            
            
            
def run(config_path):
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction, neat.DefaultSpeciesSet, neat.DefaultStagnation, config_path)
    
    p = neat.Population(config)
    
    #----STAT REPORTERS---
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    
    global gen
    gen = 0
    winner = p.run(eval_genomes, 100)
    clock = pygame.time.Clock()
    while True:
        clock.tick(30)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e:
                    run = False
    
if __name__ == "__main__":
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, "config-feedforward.txt")
    run(config_path)

